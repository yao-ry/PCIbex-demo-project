// A dome PCIbex project created by Runyi Yao
//Type code below this line.

// Remove command prefix
PennController.ResetPrefix(null)

DebugOff() // Uncomment this line only when you are 100% done designing your experiment

//showProgressBar =false //Uncomment this line if you want to hide the progress bar 

// First show consent, instructions, then practice & experiment trials, send results and show end screen
Sequence("consent", "instructions", "practice-trial","prepare", randomize("experimental-trial"), SendResults(), "end")

//Consent
newTrial ( "consent" ,

    newHtml("consent", "consent.html")
        .print()
    ,
        newTextInput("ID", "Please delete this sentence and leave your name (or participant ID) here.")
    .log()
    .print()
    .lines(0)
    .length(100)
    .size(400, 50)
    .center()
    .cssContainer({"margin-bottom":"1em"})
    ,
    newButton("<p>I have read the consent statement and I agree to continue.")
        .center()
        .print()
        .wait()
);

//Instruction
newTrial("instructions",
    defaultText
        .center()
        .print()
    ,
    newText("instructions-1", "Welcome!")
    ,
    newText("instructions-2", "<p>In this task, you will need to read some words aloud.</p>")
    ,
    newText("instructions-3", "<p><b>Your reading will be recorded.</b></p>")
    ,
    newButton("wait", "Click to see some examples.")
        .css({"font-size": "large"}) 
        .center()
        .print()
        .wait()
)


//practice trail
Template("practice.csv", row =>

    newTrial("practice-trial",
    
        newText("explain", "This is a practice trail. Please read the following word aloud:")
        .center()
        .italic()
        .cssContainer({"margin-bottom":"1em"})
        .print()
        ,
        
        newText("practice-word", row.word)
            .center()
            .settings.css("font-size", "15em")
            .cssContainer({"margin-bottom":"1em"})
            .print()
        ,


    
        newTimer("wait", 3000)
        .start()
        .wait()
)
      

);



//prepare
newTrial("prepare",
    defaultText
        .css({"font-size": "large"}) 
        .center()
        .print()
    ,
    newText("ready-1", "You have finished all practice.")
    ,
    newText("ready-2", "<p><b> Are you ready for the task? Click the buttom below to go ahead. </b></p>")
    ,
    newButton("ready-3", "Ready to start")
        .center()
        .css({"font-size": "large"}) 
        .print()
        .wait()
)

// Experimental trial


Template("stimuli.csv", row =>
    newTrial("experimental-trial",

        newText("explain", "Please read the following word aloud:")
        .center()
        .italic()
        .cssContainer({"margin-bottom":"1em"})
        .print()
        ,

        newText("word", row.word)
            .center()
            .settings.css("font-size", "15em")
            .cssContainer({"margin-bottom":"1em"})
            .print()
        ,
        
        newTimer("wait", 3000)
        .start()
        .wait()

)

            .log("POA", row.PoA)
            .log("underlying", row.underlying)
            .log("item",row.item)
    );


// Send results manually
SendResults("send");

// Final screen
newTrial("end",
    exitFullscreen()
    ,
    newText("Thank you for your participation!")
        .css({"font-size": "large"}) 
        .center()
        .print()
    ,
// Wait on this page forever
    newButton().wait()
);

